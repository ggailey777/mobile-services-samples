/** Automatically generated file. DO NOT MODIFY */
package com.mobileservices.todolistglenn;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}