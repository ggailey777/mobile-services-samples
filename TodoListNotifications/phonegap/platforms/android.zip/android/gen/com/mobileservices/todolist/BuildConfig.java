/** Automatically generated file. DO NOT MODIFY */
package com.mobileservices.todolist;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}